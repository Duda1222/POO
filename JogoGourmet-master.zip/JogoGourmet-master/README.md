# JogoGourmet

Jogo desenvolvido na linguagem Java, utilizando conceitos de lógica de programação.

O jogo consiste em adivinhar o prato em que o usuário está pensando, dando a possibilidade do usuário cadastrar
novos pratos que ainda não existam na lista.
